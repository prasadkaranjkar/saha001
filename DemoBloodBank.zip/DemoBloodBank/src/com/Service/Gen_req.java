package com.Service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DbmsService;

public class Gen_req extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		String id =(String) req.getAttribute("rid");
		System.out.println("Gen_req : " + id);
		
		String rno = req.getParameter("rno");
		System.out.println(rno);
		String donorBType = req.getParameter("btype");
		System.out.println(donorBType);
		int bottles = Integer.parseInt(req.getParameter("volume"));
		System.out.println(bottles);
			String status = "OK";
			System.out.println("data inserted from the DbmsService.regInDb with type "+id);
			DbmsService.generateReq(id,rno,donorBType,bottles,status);
			RequestDispatcher rd = req.getRequestDispatcher("./jsp/RequestDisplay.jsp");
			
	}
}

