package com.Service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DbmsService;
import com.model.Employee;

public class Emp_reg extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		System.out.println("dddgdgdg");
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		Employee e = new Employee();
		
		e.setE_fname(req.getParameter("fname"));
		e.setE_lname(req.getParameter("lname"));
		e.setE_gender(req.getParameter("gender"));
		e.setE_dob(BasicService.changeToSqlDate(req.getParameter("dob")));
		e.setE_doj(BasicService.changeToSqlDate(req.getParameter("doj")));
		e.setE_btype(req.getParameter("btype"));
		e.setE_contact(req.getParameter("empContact"));
		e.setE_eaddr(req.getParameter("email"));
		e.setE_addr(req.getParameter("addr"));
		e.setE_recovery_id(req.getParameter("recmail"));
		
		if(req.getParameter("disease")!=null) {e.setDisease(1);}else {e.setDisease(0);}
		
		if(req.getParameter("worked")!=null) {e.setE_workedEarlier("YES");}else {e.setE_workedEarlier("NO");}
		
		if(req.getParameter("wname")!=null) {e.setE_workedLocation(req.getParameter("wname"));}else {e.setE_workedLocation("null");}

		if(req.getParameter("wdesig")!=null) {e.setE_workedLocation(req.getParameter("wdesig"));}else {e.setE_workedLocation("null");}

		if(req.getParameter("twexp")!=null) {e.setE_workedLocation(req.getParameter("twexp"));}else {e.setE_workedLocation("null");}
		
		out.println(e.toString());

		int n=DbmsService.EmpInDb(e);
		if(n>0){
			System.out.println("Service-Employee : Data is added in DataBase via EmpInDb()");
		}else{
			System.out.println("Data in not added");
		}
	}
}
