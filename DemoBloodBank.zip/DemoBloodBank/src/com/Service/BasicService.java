package com.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class BasicService {
	
	public static java.util.Date changeToUtilDate(String d){
		java.util.Date dt=null;
		try {
			dt=new SimpleDateFormat("yyyy-MM-dd").parse(d);
			System.out.println("Date is : "+ dt);
		} catch (ParseException e) {
			System.out.println("Can not change into Date !! ");
		}
		return dt;
	}
	
	public static java.sql.Date changeToSqlDate(String d){
		java.util.Date dt = changeToUtilDate(d);
		java.sql.Date dte= new java.sql.Date(dt.getTime());	
		return dte;
	}
	
	
//	public static String getLastId(ResultSet rs) {
//		String id=null;
//		if(rs==null) {
//			System.out.println("basicService : the resultset coming is empty ! ");
//		}else {
//			System.out.println("basicService : Getting last value ! ");
//			try {
//				//rs.next();
//				System.out.println("basicService : rs is pointed ! ");
//				int chk=0;
//				System.out.println("basicService : chk is reset to 0 ! ");
//				while(rs.next()) {
//					chk++;
//					System.out.println("basicService : Reading next ResultSet for turn = "+ chk);
//					
//					System.out.println("\n basicService : Getting last value in table ");
//					
//					id = rs.getString(1);
//					
//					System.out.println("basicService : id is = "+ id);
//						
//					System.out.println("\n basicService : Getting last value id in out value ");
//				}
//			} catch (SQLException e) {
//				System.out.println("basicService : rs is empty ! \n ");
//				e.printStackTrace();
//			}
//		}
//		System.out.println("basicService : final id is = "+ id);
//		return id;
//	}
}