package com.Initial;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.BasicService;
import com.dao.DbmsService;

public class ForgotPwd extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		String uid=req.getParameter("uid");
		
		String d = req.getParameter("doj");
		
		System.out.println("Date in String "+d);
		
		//Date ot = BasicService.changeToUtilDate(d);
		java.sql.Date dte=BasicService.changeToSqlDate(d);
		out.println(d);
		System.out.println(dte+" for userid "+uid);
		
		out.println(dte + " Date of joining for user id " + uid);
		/*boolean b=DbmsService.userPwdChk(uid, dte);
		if(b==true){
			RequestDispatcher rd = req.getRequestDispatcher("");
			out.println("<h3 style='text-color: Green ;'>Password Retrival Succeccful.<br> a link has been sent to your registered Email to reset password!</h3>");
			rd.forward(req, resp);
		}else {
			RequestDispatcher rd = req.getRequestDispatcher("ForgotPasswd.html");
			out.println("<h3 Style='text-color : Red;'>Incorrect Details! ,Please enter again...</h3>");
			rd.include(req, resp);
		}*/
	}
}
