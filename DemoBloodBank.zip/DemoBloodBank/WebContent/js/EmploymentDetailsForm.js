/**
 * 
 */
function chk1(){
	
	document.getElementById("tr1").style.visibility="visible";
	document.getElementById("tr2").style.visibility="visible";
	document.getElementById("tr3").style.visibility="visible";
}