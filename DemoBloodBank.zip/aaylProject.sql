drop table blood_bank_requester_table;


select * from blood_bank_requester_table;


truncate table blood_bank_requester_table;


create table blood_bank_requester_table(
rid varchar2(5) not null primary key,
fname varchar2(30) not null,
lname varchar2(30) not null,
gender varchar2(6) not null,
dob DATE not null,
btype varchar2(4) not null,
contact varchar2(16) not null,
email varchar2(30) not null,
address varchar2(50) not null,
doctor varchar2(30) not null,
hospital varchar2(50) not null,
q1 number(1) not null,
q2 number(1) not null,
q3 number(1) not null,
Autologous number(1) not null
);


create or replace procedure
InsertRequesterInDb_16049(rid in varchar2,fname in varchar2,lname in varchar2,gender in varchar2,dob in DATE,btype in varchar2,contact in varchar2,email in varchar2,address in varchar2,doctor in varchar2,hospital in varchar2,q1 in number,q2 in number,q3 in number,autologous in number) as
begin
insert into blood_bank_requester_table values(rid,fname,lname,gender,dob,btype,contact,email,address,doctor,hospital,q1,q2,q3,autologous);
commit;
end InsertRequesterInDb_16049;


drop table blood_bank_to_match;


create table blood_bank_for_match(
blood_id varchar2(5) primary key,
blood_type varchar2(4) not null
);


insert into blood_bank_for_match values('b101','A+');
insert into blood_bank_for_match values('b102','A-');
insert into blood_bank_for_match values('b103','O+');
insert into blood_bank_for_match values('b104','O-');
insert into blood_bank_for_match values('b105','AB+');
insert into blood_bank_for_match values('b106','AB-');
insert into blood_bank_for_match values('b107','B+');
insert into blood_bank_for_match values('b108','B-');
select * from blood_bank_for_match;


create table blood_bank_to_match(
blood_id varchar2(5) primary key,
blood_type varchar2(4) not null
);


insert into blood_bank_to_match values('b101','A+');
insert into blood_bank_to_match values('b102','A-');
insert into blood_bank_to_match values('b103','O+');
insert into blood_bank_to_match values('b104','O-');
insert into blood_bank_to_match values('b105','AB+');
insert into blood_bank_to_match values('b106','AB-');
insert into blood_bank_to_match values('b107','B+');
insert into blood_bank_to_match values('b108','B-');
select * from blood_bank_to_match;


create or replace procedure
RetriveBloodType_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_to_match;
end RetriveBloodType_16049;


create or replace procedure
retriveDonorType(Dtype out varchar2) as 

begin

end retriveDonorType;


select * from Blood_bank_Emp_table;


drop table Blood_bank_Emp_table;


create table Blood_bank_Emp_table(
emp_id varchar2(5) not null primary key,
fname varchar2(30) not null,
lname varchar2(30) not null,
gender varchar2(8) not null,
date_birth DATE not null,
date_join DATE not null,
btype varchar2(4) not null,
contact varchar2(10) not null,
email varchar2(30) not null,
address varchar2(50) not null,
recovery_id varchar2(30),
disease number(1) not null,
worked_earlier varchar2(3),
worked_history_type varchar2(20),
worked_location varchar2(30),
worked_exp number(3)
);


create or replace procedure
InsertEmployeeInDb_16049(eid in varchar2,fnm in varchar2,lnm in varchar2
,gender in varchar2,dob in Date,doj in Date,btype in varchar2,contact in varchar2,
email in varchar2,address in varchar2,rec_id in varchar2,disease in number,workedEarlier in varchar2,
wHistoryType in varchar2,wLocation in varchar2,wExp in number) as 
begin
insert into Blood_bank_Emp_table values(eid,fnm,lnm,gender,dob,doj,btype,contact,email,address,rec_id,
disease,workedEarlier,wHistoryType,wLocation,wExp);
end InsertEmployeeInDb_16049;


drop table Blood_bank_Emp_credentials;


create table Blood_bank_Emp_credentials(
cred_id number(4) not null primary key,
emp_id varchar2(5) not null,
passwd varchar2(30) not null,
foreign key(emp_id) references Blood_bank_Emp_table(emp_id)
);


create or replace procedure
Chkcredentials_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_Emp_credentials;
end Chkcredentials_16049;


create or replace procedure
DisplayEmpTable_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_Emp_table;
end DisplayEmpTable_16049;


select * from blood_bank_requester_table;


delete from blood_bank_requester_table where rid='BR100';


truncate table blood_bank_requester_table;


select * from BLOOD_BANK_GROUP_TABLE;


drop table blood_bank_for_match;


create table blood_bank_for_match as select * from BLOOD_BANK_TO_MATCH;


select * from BLOOD_BANK_FOR_MATCH;


drop table blood_bank_blood_matching;


create table blood_bank_blood_matching(
match_id varchar2(6) primary key,
recipient_blood_type varchar2(5) not null, 
Donor_blood_type varchar2(5) not null
);


insert into blood_bank_blood_matching values('bm201','A+','A+');
insert into blood_bank_blood_matching values('bm202','A+','A-');
insert into blood_bank_blood_matching values('bm203','A+','O+');
insert into blood_bank_blood_matching values('bm204','A+','O-');
insert into blood_bank_blood_matching values('bm205','A-','A-');
insert into blood_bank_blood_matching values('bm206','A-','O-');
insert into blood_bank_blood_matching values('bm207','O+','O+');
insert into blood_bank_blood_matching values('bm208','O+','O-');
insert into blood_bank_blood_matching values('bm209','O-','O-');
insert into blood_bank_blood_matching values('bm210','AB+','A+');
insert into blood_bank_blood_matching values('bm211','AB+','A-');
insert into blood_bank_blood_matching values('bm212','AB+','O+');
insert into blood_bank_blood_matching values('bm213','AB+','O-');
insert into blood_bank_blood_matching values('bm214','AB+','AB+');
insert into blood_bank_blood_matching values('bm215','AB+','AB-');
insert into blood_bank_blood_matching values('bm216','AB+','B+');
insert into blood_bank_blood_matching values('bm217','AB+','B-');
insert into blood_bank_blood_matching values('bm218','AB-','B-');
insert into blood_bank_blood_matching values('bm219','AB-','AB-');
insert into blood_bank_blood_matching values('bm220','AB-','O-');
insert into blood_bank_blood_matching values('bm221','AB-','A-');
insert into blood_bank_blood_matching values('bm222','B+','O+');
insert into blood_bank_blood_matching values('bm223','B+','O-');
insert into blood_bank_blood_matching values('bm224','B+','B+');
insert into blood_bank_blood_matching values('bm225','B+','B-');
insert into blood_bank_blood_matching values('bm226','B-','B-');
insert into blood_bank_blood_matching values('bm227','B-','O-');


select * from blood_bank_blood_matching;



create or replace procedure
provide_required_blood_type(rtype in varchar2,faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_blood_matching where recipient_blood_type = rtype;
end;


drop table Blood_bank_request_done;



create table Blood_bank_request_done(
request_id number(3) primary key,
rid varchar2(5) not null,
roomNo varchar2(4),
DonorType varchar2(5) not null,
bottles number(2) not null,
status varchar2(5) not null,
foreign key(rid) references blood_bank_requester_table(rid)
);



create or replace procedure
insert_req_accident(req_id in varchar2,rid in varchar2,rno in varchar2,
DType in varchar2,nob in number,req_status in varchar2) as 
begin
insert into Blood_bank_request_done values(req_id,rid,rno,DType,nob,req_status);
commit;
end insert_req_accident;



create or replace procedure
Get_requester_table(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_requester_table;
end;


create or replace procedure
Get_employee_table(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_Emp_table;
end;


select * from Product_16049_new;


commit;


drop table product_16049_new;


create or replace procedure
get_generated_table(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_request_done;
end get_generated_table;


select max(TO_NUMBER(SUBSTR(rid,3)))+1 FROM blood_bank_requester_table;


select TO_NUMBER(SUBSTR(rid FROM blood_bank_requester_table;


select * from blood_bank_requester_table;


CREATE OR REPLACE PROCEDURE
GET_MAX_REQID(table_typ in varchar2,O_ID OUT NUMBER) AS 
BEGIN
if table_typ = 'BR' then
select max(TO_NUMBER(SUBSTR(rid,3)))+1 INTO O_ID FROM blood_bank_requester_table;
elsif table_typ = 'BE' then
select max(TO_NUMBER(SUBSTR(emp_id,3)))+1 INTO O_ID FROM Blood_bank_Emp_table;
elsif table_typ = 'GR' then
select max(TO_NUMBER(SUBSTR(request_id,3)))+1 INTO O_ID FROM Blood_bank_request_done;
end if;
commit;
END GET_MAX_REQID;

